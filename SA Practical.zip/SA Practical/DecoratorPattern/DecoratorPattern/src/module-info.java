/**
 * 
 */
/**
 * @author Mahreen-PC
 *
 */
module DecoratorPattern {
}