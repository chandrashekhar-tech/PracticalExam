package Pizza;

public class VeggiePizza extends Pizza{

	public VeggiePizza() {
		
		name = "Veggie Pizza";
		dough = "Crust";
		sauce = "Marinara sauce";
		toppings.add("Shredded Mozzarella");
		toppings.add("Grated Parmesan");
		toppings.add("Diced Onion");
		toppings.add("Sliced Mushrooms");
		toppings.add("Sliced Red Peppers");
		toppings.add("Sliced Baked Olives");
		
	}
	
}
