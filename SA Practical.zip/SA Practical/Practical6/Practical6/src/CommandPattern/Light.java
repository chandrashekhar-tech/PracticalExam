package CommandPattern;

public class Light {

	public void on() {
		System.out.print("on");
	}
	public static void off() {
		System.out.print("off");
	}
	
}
