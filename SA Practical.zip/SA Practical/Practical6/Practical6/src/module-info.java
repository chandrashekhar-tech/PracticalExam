/**
 * 
 */
/**
 * @author Mahreen-PC
 *
 */
module Practical6 {
}