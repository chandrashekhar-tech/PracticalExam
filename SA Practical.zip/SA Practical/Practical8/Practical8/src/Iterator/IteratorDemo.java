package Iterator;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Iterator;

public class IteratorDemo {

	public static void main(String[] args) {
		
		DinnerMenu dinnerMenu = new DinnerMenu();
		Waitress w = new Waitress(dinnerMenu, dinnerMenu, dinnerMenu);
		w.printMenu();
		
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(1);
		al.add(2);
		al.add(3);
		al.add(4);
		al.add(5);
		for (Integer i:al) {
			System.out.println(i);
		}
		
		System.out.println("====================================");
		
		Iterator<Integer> ArrIter = al.iterator();
		while(ArrIter.hasNext()) {
			Integer i = ArrIter.next();
			System.out.println(i);
		}
		
		System.out.println("====================================");
		
		LinkedList<Integer> ll = new LinkedList<Integer>();
		ll.add(1);
		ll.add(2);
		ll.add(3);
		ll.add(4);
		ll.add(5);
		for (Integer i:ll) {
			System.out.println(i);
		}
		
		System.out.println("====================================");
		
		Iterator<Integer> LLIter = ll.iterator();
		while(LLIter.hasNext()) {
			Integer i = LLIter.next();
			System.out.println(i);
		}
	}
	
}
